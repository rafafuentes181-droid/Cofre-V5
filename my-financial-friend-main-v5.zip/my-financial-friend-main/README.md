# My Financial Friend

quero criar um app, que possa acessar pelo celular ou site, para controle de finanças pessoais, onde possa lançar extrato de conta corrente, fatura de cartão de crédito, classificar as entradas e saidas, que tenha análise dos gastos e até sugestões de economias, que no app tenha uma opção fácil de lançar um gasto, para tentar ser o mais fiel possível.

por onde começamos?

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/b15ae1c5-301a-4b90-8cdf-186bc371778c).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
