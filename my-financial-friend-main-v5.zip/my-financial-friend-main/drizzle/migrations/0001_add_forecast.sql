ALTER TABLE public.transactions ADD COLUMN is_forecast boolean NOT NULL DEFAULT false;
ALTER TABLE public.transactions ADD COLUMN recurrence_group uuid;