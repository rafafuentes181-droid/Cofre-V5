import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — Cofre" },
      { name: "description", content: "Acesse sua conta do Cofre para controlar suas finanças." },
      { property: "og:title", content: "Entrar — Cofre" },
      { property: "og:description", content: "Acesse sua conta do Cofre para controlar suas finanças." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { full_name: name } },
        });
        if (error) throw error;
        toast.success("Conta criada! Verifique seu e-mail para confirmar.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/" });
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Algo deu errado");
    } finally {
      setLoading(false);
    }
  }

  async function handleSocial(provider: "google" | "apple") {
    setLoading(true);
    try {
      const result = await lovable.auth.signInWithOAuth(provider, {
        redirect_uri: window.location.origin,
      });
      if (result.error) throw result.error;
      if (result.redirected) return;
      navigate({ to: "/" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Não foi possível entrar");
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <span className="inline-grid size-12 place-items-center rounded-full bg-ink text-paper text-xl font-display">
            ₿
          </span>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight font-display">Cofre</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Suas finanças sob controle, no celular e no site.
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="space-y-3 rounded-3xl border border-line bg-card p-6"
        >
          {mode === "signup" && (
            <div>
              <label className="mb-1 block text-[13px] font-medium">Nome</label>
              <input
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                placeholder="Seu nome"
              />
            </div>
          )}
          <div>
            <label className="mb-1 block text-[13px] font-medium">E-mail</label>
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
              placeholder="voce@email.com"
            />
          </div>
          <div>
            <label className="mb-1 block text-[13px] font-medium">Senha</label>
            <input
              required
              type="password"
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
              placeholder="••••••••"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-full bg-ink py-2.5 text-sm font-medium text-paper transition-opacity hover:opacity-90 disabled:opacity-50"
          >
          {loading ? "Aguarde…" : mode === "login" ? "Entrar" : "Criar conta"}
          </button>
          <div className="flex items-center gap-3 py-1">
            <span className="h-px flex-1 bg-line" />
            <span className="text-[11px] uppercase tracking-widest text-muted-foreground">ou</span>
            <span className="h-px flex-1 bg-line" />
          </div>
          <button
            type="button"
            disabled={loading}
            onClick={() => handleSocial("google")}
            className="flex w-full items-center justify-center gap-2 rounded-full border border-input bg-background py-2.5 text-sm font-medium transition-opacity hover:bg-muted/50 disabled:opacity-50"
          >
            <svg viewBox="0 0 24 24" className="size-4" aria-hidden>
              <path fill="#4285F4" d="M23.5 12.3c0-.9-.1-1.5-.3-2.2H12v4.1h6.5c-.1 1.1-.8 2.7-2.4 3.8l-.02.15 3.5 2.7.24.02c2.2-2 3.5-5 3.5-8.6" />
              <path fill="#34A853" d="M12 24c3.2 0 5.9-1.1 7.9-2.9l-3.8-2.9c-1 .7-2.4 1.2-4.1 1.2-3.2 0-5.8-2.1-6.8-4.9l-.14.01-3.6 2.8-.05.13C3.4 21.3 7.4 24 12 24" />
              <path fill="#FBBC05" d="M5.2 14.5c-.25-.75-.4-1.55-.4-2.4s.15-1.7.4-2.5l-.01-.16-3.7-2.9-.12.06A12 12 0 0 0 0 12.1c0 1.9.46 3.8 1.37 5.5z" />
              <path fill="#EA4335" d="M12 4.7c2.3 0 3.8 1 4.7 1.8l3.4-3.3C18 1.2 15.2 0 12 0 7.4 0 3.4 2.6 1.4 6.5l3.8 3c1-2.9 3.6-4.8 6.8-4.8" />
            </svg>
            Continuar com Google
          </button>
          <button
            type="button"
            disabled={loading}
            onClick={() => handleSocial("apple")}
            className="flex w-full items-center justify-center gap-2 rounded-full border border-input bg-background py-2.5 text-sm font-medium transition-opacity hover:bg-muted/50 disabled:opacity-50"
          >
            <svg viewBox="0 0 24 24" className="size-4 fill-foreground" aria-hidden>
              <path d="M17.05 12.54c-.03-2.6 2.12-3.85 2.22-3.91-1.21-1.77-3.1-2.01-3.77-2.04-1.6-.16-3.13.94-3.94.94-.81 0-2.07-.92-3.4-.9-1.75.03-3.36 1.02-4.26 2.58-1.82 3.15-.46 7.81 1.3 10.37.87 1.25 1.9 2.66 3.25 2.61 1.31-.05 1.8-.84 3.38-.84 1.58 0 2.02.84 3.4.81 1.4-.02 2.29-1.27 3.15-2.53 1-1.46 1.4-2.87 1.43-2.94-.03-.02-2.73-1.05-2.76-4.15M14.56 4.86c.72-.87 1.2-2.08 1.07-3.28-1.03.04-2.28.69-3.02 1.56-.66.77-1.24 2-1.09 3.18 1.15.09 2.32-.58 3.04-1.46" />
            </svg>
            Continuar com Apple
          </button>
          <button
            type="button"
            onClick={() => setMode(mode === "login" ? "signup" : "login")}
            className="w-full text-center text-[13px] text-muted-foreground hover:text-foreground"
          >
            {mode === "login" ? "Não tem conta? Cadastre-se" : "Já tem conta? Entrar"}
          </button>
        </form>
      </div>
    </div>
  );
}
