import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Trash2, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORIES, formatBRL, formatDateBR } from "@/lib/finance";
import { useAccounts, useTransactions } from "./index";

export const Route = createFileRoute("/_authenticated/extratos")({
  head: () => ({
    meta: [
      { title: "Extratos — Cofre" },
      { name: "description", content: "Todos os lançamentos da sua conta corrente e cartões, com filtros por categoria." },
      { property: "og:title", content: "Extratos — Cofre" },
      { property: "og:description", content: "Todos os lançamentos da sua conta corrente e cartões, com filtros por categoria." },
    ],
  }),
  component: ExtratosPage,
});

function ExtratosPage() {
  const queryClient = useQueryClient();
  const { data: transactions = [], isLoading } = useTransactions();
  const { data: accounts = [] } = useAccounts();
  const [filter, setFilter] = useState<string>("todas");
  const [newAccount, setNewAccount] = useState("");

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("transactions").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      toast.success("Lançamento removido");
    },
    onError: () => toast.error("Não foi possível remover"),
  });

  const forecastMutation = useMutation({
    mutationFn: async ({ id, value }: { id: string; value: boolean }) => {
      const { error } = await supabase.from("transactions").update({ is_forecast: value }).eq("id", id);
      if (error) throw error;
      return value;
    },
    onSuccess: (value) => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      toast.success(value ? "Marcado como previsão" : "Confirmado — agora compõe o saldo real");
    },
    onError: () => toast.error("Não foi possível atualizar"),
  });

  const addAccountMutation = useMutation({
    mutationFn: async (name: string) => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Sessão expirada");
      const { error } = await supabase.from("accounts").insert({ user_id: userData.user.id, name });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["accounts"] });
      setNewAccount("");
      toast.success("Conta adicionada");
    },
    onError: () => toast.error("Não foi possível adicionar a conta"),
  });

  const filtered =
    filter === "todas" ? transactions : transactions.filter((t) => t.category === filter);

  const totalEntradas = filtered.filter((t) => t.type === "entrada").reduce((s, t) => s + t.amount, 0);
  const totalSaidas = filtered.filter((t) => t.type === "saida").reduce((s, t) => s + t.amount, 0);

  return (
    <div className="mt-8 space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">Extratos</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {filtered.length} lançamentos · entradas {formatBRL(totalEntradas)} · saídas {formatBRL(totalSaidas)}
          </p>
        </div>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="rounded-full border border-input bg-card px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
        >
          <option value="todas">Todas as categorias</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {/* Contas */}
      <section className="rounded-3xl border border-line bg-card p-6">
        <h3 className="mb-3 font-display text-lg font-semibold">Minhas contas</h3>
        <div className="flex flex-wrap items-center gap-2">
          {accounts.map((a) => (
            <span key={a.id} className="rounded-full bg-secondary px-3 py-1 text-sm">
              {a.name}
            </span>
          ))}
          <form
            className="flex items-center gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (newAccount.trim()) addAccountMutation.mutate(newAccount.trim());
            }}
          >
            <input
              value={newAccount}
              onChange={(e) => setNewAccount(e.target.value)}
              placeholder="Nova conta (ex.: Nubank)"
              className="rounded-full border border-input bg-background px-3 py-1.5 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              type="submit"
              className="grid size-8 place-items-center rounded-full bg-ink text-paper"
              title="Adicionar conta"
            >
              <Plus className="size-4" />
            </button>
          </form>
        </div>
      </section>

      {/* Lista */}
      <section className="rounded-3xl border border-line bg-card p-6">
        {isLoading ? (
          <p className="py-6 text-center text-sm text-muted-foreground">Carregando…</p>
        ) : filtered.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">
            Nenhum lançamento encontrado.
          </p>
        ) : (
          <div className="divide-y divide-line">
            {filtered.map((t) => (
              <div key={t.id} className="group flex items-center gap-4 py-3.5">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{t.description}</p>
                  <p className="text-[13px] text-ink/50">
                    {t.category} · {t.source === "cartao" ? "Cartão" : "Conta"} · {formatDateBR(t.occurred_at)}
                  </p>
                </div>
                <label
                  className={`flex shrink-0 cursor-pointer items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold uppercase ${
                    t.is_forecast ? "bg-gold/20 text-ink" : "bg-secondary text-ink/40"
                  }`}
                  title={t.is_forecast ? "Desmarque para confirmar como real" : "Marcar como previsão"}
                >
                  <input
                    type="checkbox"
                    checked={t.is_forecast}
                    onChange={(e) => forecastMutation.mutate({ id: t.id, value: e.target.checked })}
                    className="size-3.5 accent-current"
                  />
                  Previsão
                </label>
                <span
                  className={`w-28 shrink-0 text-right font-semibold ${
                    t.type === "entrada" ? "text-sage" : "text-terracotta"
                  }`}
                >
                  {t.type === "entrada" ? "+" : "-"}
                  {formatBRL(t.amount)}
                </span>
                <button
                  onClick={() => deleteMutation.mutate(t.id)}
                  className="grid size-8 shrink-0 place-items-center rounded-full text-ink/30 opacity-0 transition-opacity hover:bg-terracotta/10 hover:text-terracotta group-hover:opacity-100"
                  title="Remover"
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
