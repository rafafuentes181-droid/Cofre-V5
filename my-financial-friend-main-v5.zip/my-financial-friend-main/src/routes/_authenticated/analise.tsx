import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { CATEGORY_COLORS, formatBRL, monthKey } from "@/lib/finance";
import { useTransactions } from "./index";

export const Route = createFileRoute("/_authenticated/analise")({
  head: () => ({
    meta: [
      { title: "Análise — Cofre" },
      { name: "description", content: "Análise dos seus gastos por categoria e evolução mês a mês." },
      { property: "og:title", content: "Análise — Cofre" },
      { property: "og:description", content: "Análise dos seus gastos por categoria e evolução mês a mês." },
    ],
  }),
  component: AnalisePage,
});

function AnalisePage() {
  const { data: transactions = [] } = useTransactions();
  const [offset, setOffset] = useState(0);

  const ref = new Date();
  ref.setMonth(ref.getMonth() - offset);
  const key = monthKey(ref);
  const label = ref.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

  const monthTx = transactions.filter((t) => t.occurred_at.startsWith(key));
  const entradas = monthTx.filter((t) => t.type === "entrada").reduce((s, t) => s + t.amount, 0);
  const saidas = monthTx.filter((t) => t.type === "saida").reduce((s, t) => s + t.amount, 0);

  const byCategory = new Map<string, number>();
  for (const t of monthTx.filter((t) => t.type === "saida")) {
    byCategory.set(t.category, (byCategory.get(t.category) ?? 0) + t.amount);
  }
  const categories = [...byCategory.entries()].sort((a, b) => b[1] - a[1]);
  const maxCat = categories[0]?.[1] ?? 1;

  // Last 6 months evolution
  const months: { label: string; entradas: number; saidas: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const k = monthKey(d);
    const tx = transactions.filter((t) => t.occurred_at.startsWith(k));
    months.push({
      label: d.toLocaleDateString("pt-BR", { month: "short" }).replace(".", ""),
      entradas: tx.filter((t) => t.type === "entrada").reduce((s, t) => s + t.amount, 0),
      saidas: tx.filter((t) => t.type === "saida").reduce((s, t) => s + t.amount, 0),
    });
  }
  const maxMonth = Math.max(...months.flatMap((m) => [m.entradas, m.saidas]), 1);

  return (
    <div className="mt-8 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">Análise</h1>
          <p className="mt-1 text-sm text-muted-foreground">Para onde seu dinheiro está indo.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setOffset((o) => o + 1)}
            className="grid size-9 place-items-center rounded-full border border-line bg-card"
            title="Mês anterior"
          >
            <ChevronLeft className="size-4" />
          </button>
          <span className="w-32 text-center text-sm font-medium capitalize">{label}</span>
          <button
            onClick={() => setOffset((o) => Math.max(0, o - 1))}
            disabled={offset === 0}
            className="grid size-9 place-items-center rounded-full border border-line bg-card disabled:opacity-40"
            title="Próximo mês"
          >
            <ChevronRight className="size-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl border border-line bg-card px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.14em] text-ink/45">Entradas</p>
          <p className="mt-1 text-lg font-semibold text-sage">{formatBRL(entradas)}</p>
        </div>
        <div className="rounded-2xl border border-line bg-card px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.14em] text-ink/45">Saídas</p>
          <p className="mt-1 text-lg font-semibold text-terracotta">{formatBRL(saidas)}</p>
        </div>
        <div className="rounded-2xl border border-line bg-card px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.14em] text-ink/45">Saldo do mês</p>
          <p className={`mt-1 text-lg font-semibold ${entradas - saidas >= 0 ? "text-sage" : "text-terracotta"}`}>
            {formatBRL(entradas - saidas)}
          </p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-3xl border border-line bg-card p-6">
          <h3 className="mb-4 font-display text-lg font-semibold">Gastos por categoria</h3>
          {categories.length === 0 ? (
            <p className="py-4 text-sm text-muted-foreground">Sem gastos neste mês.</p>
          ) : (
            <div className="space-y-4">
              {categories.map(([cat, total]) => (
                <div key={cat}>
                  <div className="mb-1 flex justify-between text-[13px]">
                    <span>{cat}</span>
                    <span className="text-ink/50">
                      {formatBRL(total)} · {saidas > 0 ? Math.round((total / saidas) * 100) : 0}%
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-line">
                    <div
                      className={`h-full rounded-full transition-all ${CATEGORY_COLORS[cat] ?? "bg-ink/40"}`}
                      style={{ width: `${Math.round((total / maxCat) * 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="rounded-3xl border border-line bg-card p-6">
          <h3 className="mb-4 font-display text-lg font-semibold">Últimos 6 meses</h3>
          <div className="flex h-48 items-end gap-4">
            {months.map((m, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-2">
                <div className="flex h-36 w-full items-end justify-center gap-1">
                  <div
                    className="w-1/3 rounded-t bg-sage/80 transition-all"
                    style={{ height: `${Math.max(2, (m.entradas / maxMonth) * 100)}%` }}
                    title={`Entradas ${formatBRL(m.entradas)}`}
                  />
                  <div
                    className="w-1/3 rounded-t bg-terracotta/80 transition-all"
                    style={{ height: `${Math.max(2, (m.saidas / maxMonth) * 100)}%` }}
                    title={`Saídas ${formatBRL(m.saidas)}`}
                  />
                </div>
                <span className="text-[11px] capitalize text-ink/55">{m.label}</span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex justify-center gap-5 text-[12px] text-ink/60">
            <span className="flex items-center gap-1.5">
              <span className="size-2.5 rounded-sm bg-sage/80" /> Entradas
            </span>
            <span className="flex items-center gap-1.5">
              <span className="size-2.5 rounded-sm bg-terracotta/80" /> Saídas
            </span>
          </div>
        </section>
      </div>
    </div>
  );
}
