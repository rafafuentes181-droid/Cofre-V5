import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  buildSuggestions,
  formatBRL,
  formatDateBR,
  monthKey,
  type Account,
  type CreditCard,
  type Transaction,
} from "@/lib/finance";

export const Route = createFileRoute("/_authenticated/")({
  head: () => ({
    meta: [
      { title: "Painel — Cofre" },
      { name: "description", content: "Visão geral das suas finanças: saldo, gastos do mês, faturas e lançamentos recentes." },
      { property: "og:title", content: "Painel — Cofre" },
      { property: "og:description", content: "Visão geral das suas finanças: saldo, gastos do mês, faturas e lançamentos recentes." },
    ],
  }),
  component: Dashboard,
});

export function useTransactions() {
  return useQuery({
    queryKey: ["transactions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("transactions")
        .select("*")
        .order("occurred_at", { ascending: false });
      if (error) throw error;
      return (data ?? []).map((t) => ({ ...t, amount: Number(t.amount) })) as Transaction[];
    },
  });
}

export function useCards() {
  return useQuery({
    queryKey: ["credit_cards"],
    queryFn: async () => {
      const { data, error } = await supabase.from("credit_cards").select("*").order("name");
      if (error) throw error;
      return data as CreditCard[];
    },
  });
}

export function useAccounts() {
  return useQuery({
    queryKey: ["accounts"],
    queryFn: async () => {
      const { data, error } = await supabase.from("accounts").select("*").order("name");
      if (error) throw error;
      return data as Account[];
    },
  });
}

const CATEGORY_EMOJI: Record<string, string> = {
  Moradia: "🏠",
  Mercado: "🛒",
  Restaurantes: "🍔",
  Transporte: "🚕",
  Lazer: "🎬",
  Assinaturas: "🔁",
  Saúde: "💊",
  Educação: "📚",
  Renda: "💰",
  Outros: "📦",
};

function HideToggle({ shown, onToggle }: { shown: boolean; onToggle: () => void }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={shown ? "Ocultar" : "Mostrar"}
      className="rounded-full p-1.5 text-ink/50 transition-colors hover:bg-secondary hover:text-ink"
    >
      {shown ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
    </button>
  );
}

function Dashboard() {
  const [showBalance, setShowBalance] = useState(false);
  const [showRecent, setShowRecent] = useState(false);
  const [showCats, setShowCats] = useState(false);
  const { data: transactions = [], isLoading } = useTransactions();
  const { data: cards = [] } = useCards();
  const { data: accounts = [] } = useAccounts();

  const now = new Date();
  const thisMonthKey = monthKey(now);
  const realTx = transactions.filter((t) => !t.is_forecast);
  const monthTx = realTx.filter((t) => t.occurred_at.startsWith(thisMonthKey));
  const entradas = monthTx.filter((t) => t.type === "entrada").reduce((s, t) => s + t.amount, 0);
  const saidas = monthTx.filter((t) => t.type === "saida").reduce((s, t) => s + t.amount, 0);
  const signed = (t: Transaction) => (t.type === "entrada" ? t.amount : -t.amount);
  const saldoReal = realTx.filter((t) => t.source === "conta").reduce((s, t) => s + signed(t), 0);
  const previsao = transactions
    .filter((t) => t.is_forecast && t.source === "conta")
    .reduce((s, t) => s + signed(t), 0);
  const saldoProjetado = saldoReal + previsao;
  const economizado = entradas - saidas;

  const byCategory = new Map<string, number>();
  for (const t of monthTx.filter((t) => t.type === "saida")) {
    byCategory.set(t.category, (byCategory.get(t.category) ?? 0) + t.amount);
  }
  const topCategories = [...byCategory.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4);
  const maxCat = topCategories[0]?.[1] ?? 1;

  const tips = buildSuggestions(transactions);
  const recent = transactions.slice(0, 5);
  const firstCard = cards[0];
  const cardSpent = firstCard
    ? monthTx.filter((t) => t.card_id === firstCard.id && t.type === "saida").reduce((s, t) => s + t.amount, 0)
    : 0;

  const todayLabel = now.toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" });

  if (isLoading) {
    return <p className="mt-16 text-center text-sm text-muted-foreground">Carregando suas finanças…</p>;
  }

  return (
    <>
      <p className="mt-2 text-[13px] capitalize text-ink/45">{todayLabel}</p>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-12">
        <main className="space-y-6 lg:col-span-8">
          {/* Saldo consolidado */}
          <section className="rounded-3xl bg-ink p-7 text-paper lg:p-9">
            <div className="flex items-start justify-between gap-4">
              <p className="text-[13px] uppercase tracking-[0.15em] text-paper/50">Saldo em conta</p>
              <button
                type="button"
                onClick={() => setShowBalance((v) => !v)}
                aria-label={showBalance ? "Ocultar saldo" : "Mostrar saldo"}
                className="rounded-full p-1.5 text-paper/60 transition-colors hover:bg-paper/10 hover:text-paper"
              >
                {showBalance ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
              </button>
            </div>
            <p className="mt-1 text-[12px] uppercase tracking-[0.12em] text-paper/40">Real</p>
            <p className="font-display text-5xl font-medium tracking-tight lg:text-6xl">
              {showBalance ? formatBRL(saldoReal) : "R$ ••••••"}
            </p>
            <div className="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-sm">
              <span className="text-paper/60">
                Previsões <span className="font-semibold text-paper">{showBalance ? formatBRL(previsao) : "••••"}</span>
              </span>
              <span className="text-paper/60">
                Projetado <span className="font-semibold text-gold">{showBalance ? formatBRL(saldoProjetado) : "••••"}</span>
              </span>
            </div>
            <p className="mt-2 text-sm text-paper/60">
              {accounts.length > 0 ? accounts.map((a) => a.name).join(" · ") : "Cadastre suas contas em Extratos"}
              {cards.length > 0 && ` · ${cards.map((c) => c.name).join(" · ")}`}
            </p>
            <div className="mt-6 flex flex-wrap gap-3 text-[13px]">
              <span className="rounded-full bg-paper/10 px-3 py-1">
                Entradas <span className="font-semibold text-gold">{formatBRL(entradas)}</span>
              </span>
              <span className="rounded-full bg-paper/10 px-3 py-1">
                Saídas <span className="font-semibold text-terracotta">{formatBRL(saidas)}</span>
              </span>
              <span className="rounded-full bg-paper/10 px-3 py-1">
                Economizado <span className="font-semibold text-sage">{formatBRL(Math.max(economizado, 0))}</span>
              </span>
            </div>
          </section>

          {/* Lançamentos recentes */}
          <section className="rounded-3xl border border-line bg-card p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Lançamentos recentes</h3>
              <div className="flex items-center gap-2">
                <Link to="/extratos" className="text-[13px] text-ink/50 hover:text-ink">
                  ver extrato →
                </Link>
                <HideToggle shown={showRecent} onToggle={() => setShowRecent((v) => !v)} />
              </div>
            </div>
            {!showRecent ? (
              <p className="py-6 text-center text-sm text-muted-foreground">Oculto. Toque no olho para ver.</p>
            ) : recent.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">
                Nenhum lançamento ainda. Toque em “+ Lançar gasto” para começar.
              </p>
            ) : (
              <div className="divide-y divide-line">
                {recent.map((t) => (
                  <div key={t.id} className="flex items-center gap-4 py-3.5">
                    <span
                      className={`grid size-10 shrink-0 place-items-center rounded-full ${
                        t.type === "entrada" ? "bg-sage/15" : "bg-terracotta/12"
                      }`}
                    >
                      {CATEGORY_EMOJI[t.category] ?? "📦"}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium">{t.description}</p>
                      <p className="text-[13px] text-ink/50">
                        {t.category} · {t.source === "cartao" ? "Cartão" : "Conta"}
                        {t.is_forecast && <span className="ml-2 rounded-full bg-gold/20 px-2 py-0.5 text-[11px] font-semibold uppercase">Previsão</span>}
                      </p>
                    </div>
                    <span className="hidden text-sm text-ink/50 sm:block">{formatDateBR(t.occurred_at)}</span>
                    <span
                      className={`w-28 shrink-0 text-right font-semibold ${
                        t.type === "entrada" ? "text-sage" : "text-terracotta"
                      }`}
                    >
                      {t.type === "entrada" ? "+" : "-"}
                      {formatBRL(t.amount)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Fatura em destaque */}
          {firstCard && (
            <section className="rounded-3xl border border-line bg-card p-6">
              <h3 className="mb-4 font-display text-lg font-semibold">
                Fatura do cartão · {firstCard.name}
              </h3>
              <div className="mb-2 flex items-center justify-between text-sm">
                <span className="text-ink/60">Consumido no mês</span>
                <span className="font-semibold">
                  {formatBRL(cardSpent)} de {formatBRL(firstCard.credit_limit)}
                </span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-line">
                <div
                  className="h-full rounded-full bg-terracotta transition-all"
                  style={{
                    width: `${Math.min(100, firstCard.credit_limit > 0 ? (cardSpent / firstCard.credit_limit) * 100 : 0)}%`,
                  }}
                />
              </div>
              <p className="mt-3 text-[13px] text-ink/50">Vence todo dia {firstCard.due_day}</p>
            </section>
          )}
        </main>

        <aside className="space-y-6 lg:col-span-4">
          {/* Sugestão de economia */}
          <section className="rounded-3xl bg-sage p-6 text-paper">
            <p className="text-[13px] uppercase tracking-[0.15em] text-paper/60">Sugestão de economia</p>
            <p className="mt-2 font-display text-xl font-medium leading-snug">{tips[0]}</p>
            <Link
              to="/sugestoes"
              className="mt-4 inline-block rounded-full bg-paper px-4 py-2 text-sm font-medium text-sage"
            >
              Ver todas
            </Link>
          </section>

          {/* Gastos por categoria */}
          <section className="rounded-3xl border border-line bg-card p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Gastos por categoria</h3>
              <HideToggle shown={showCats} onToggle={() => setShowCats((v) => !v)} />
            </div>
            {!showCats ? (
              <p className="text-sm text-muted-foreground">Oculto. Toque no olho para ver.</p>
            ) : topCategories.length === 0 ? (
              <p className="text-sm text-muted-foreground">Sem gastos neste mês ainda.</p>
            ) : (
              <div className="space-y-4">
                {topCategories.map(([cat, total]) => (
                  <div key={cat}>
                    <div className="mb-1 flex justify-between text-[13px]">
                      <span>{cat}</span>
                      <span className="text-ink/50">{formatBRL(total)}</span>
                    </div>
                    <div className="h-2 rounded-full bg-line">
                      <div
                        className="h-full rounded-full bg-sage transition-all"
                        style={{ width: `${Math.round((total / maxCat) * 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </aside>
      </div>
    </>
  );
}
