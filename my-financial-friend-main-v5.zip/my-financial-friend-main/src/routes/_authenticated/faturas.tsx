import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { formatBRL, monthKey } from "@/lib/finance";
import { useCards, useTransactions } from "./index";

export const Route = createFileRoute("/_authenticated/faturas")({
  head: () => ({
    meta: [
      { title: "Faturas — Cofre" },
      { name: "description", content: "Acompanhe o limite e a fatura de cada cartão de crédito." },
      { property: "og:title", content: "Faturas — Cofre" },
      { property: "og:description", content: "Acompanhe o limite e a fatura de cada cartão de crédito." },
    ],
  }),
  component: FaturasPage,
});

function FaturasPage() {
  const queryClient = useQueryClient();
  const { data: cards = [] } = useCards();
  const { data: transactions = [] } = useTransactions();
  const [name, setName] = useState("");
  const [limit, setLimit] = useState("");
  const [dueDay, setDueDay] = useState("10");

  const thisMonthKey = monthKey(new Date());

  const addCard = useMutation({
    mutationFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Sessão expirada");
      const parsedLimit = Number(limit.replace(",", ".")) || 0;
      const { error } = await supabase.from("credit_cards").insert({
        user_id: userData.user.id,
        name: name.trim(),
        credit_limit: parsedLimit,
        due_day: Number(dueDay) || 10,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["credit_cards"] });
      setName("");
      setLimit("");
      toast.success("Cartão adicionado");
    },
    onError: () => toast.error("Não foi possível adicionar o cartão"),
  });

  const removeCard = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("credit_cards").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["credit_cards"] });
      toast.success("Cartão removido");
    },
  });

  const inputCls =
    "rounded-xl border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring";

  return (
    <div className="mt-8 space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight">Faturas</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Gastos do mês em cada cartão, comparados ao limite.
        </p>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (name.trim()) addCard.mutate();
        }}
        className="flex flex-wrap items-center gap-2 rounded-3xl border border-line bg-card p-4"
      >
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nome do cartão (ex.: Nubank Visa)"
          className={`${inputCls} min-w-48 flex-1`}
        />
        <input
          value={limit}
          onChange={(e) => setLimit(e.target.value)}
          placeholder="Limite (R$)"
          inputMode="decimal"
          className={`${inputCls} w-32`}
        />
        <input
          value={dueDay}
          onChange={(e) => setDueDay(e.target.value)}
          placeholder="Dia venc."
          inputMode="numeric"
          className={`${inputCls} w-24`}
        />
        <button
          type="submit"
          className="flex items-center gap-1 rounded-full bg-ink px-4 py-2 text-sm font-medium text-paper"
        >
          <Plus className="size-4" /> Adicionar
        </button>
      </form>

      {cards.length === 0 ? (
        <p className="rounded-3xl border border-line bg-card p-8 text-center text-sm text-muted-foreground">
          Nenhum cartão cadastrado. Adicione o primeiro acima.
        </p>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {cards.map((card) => {
            const spent = transactions
              .filter((t) => t.card_id === card.id && t.type === "saida" && t.occurred_at.startsWith(thisMonthKey))
              .reduce((s, t) => s + t.amount, 0);
            const pct = card.credit_limit > 0 ? Math.min(100, (spent / card.credit_limit) * 100) : 0;
            return (
              <section key={card.id} className="rounded-3xl bg-ink p-6 text-paper">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-[13px] uppercase tracking-[0.15em] text-paper/50">{card.name}</p>
                    <p className="mt-2 font-display text-3xl font-medium">{formatBRL(spent)}</p>
                    <p className="mt-1 text-[13px] text-paper/60">
                      de {formatBRL(card.credit_limit)} · vence dia {card.due_day}
                    </p>
                  </div>
                  <button
                    onClick={() => removeCard.mutate(card.id)}
                    className="grid size-8 place-items-center rounded-full text-paper/40 hover:bg-paper/10 hover:text-paper"
                    title="Remover cartão"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
                <div className="mt-4 h-2 overflow-hidden rounded-full bg-paper/15">
                  <div
                    className={`h-full rounded-full transition-all ${pct > 80 ? "bg-terracotta" : "bg-gold"}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <p className="mt-2 text-[12px] text-paper/50">{Math.round(pct)}% do limite usado</p>
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
}
