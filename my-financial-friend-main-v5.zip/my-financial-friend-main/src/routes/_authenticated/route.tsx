import { createFileRoute, Outlet, redirect, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { LayoutDashboard, Receipt, CreditCard, ChartPie, Lightbulb, LogOut, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { QuickAddDialog } from "@/components/QuickAddDialog";

export const Route = createFileRoute("/_authenticated")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      throw redirect({ to: "/auth" });
    }
  },
  component: AuthenticatedLayout,
});

const NAV = [
  { to: "/", label: "Painel", icon: LayoutDashboard },
  { to: "/extratos", label: "Extratos", icon: Receipt },
  { to: "/faturas", label: "Faturas", icon: CreditCard },
  { to: "/analise", label: "Análise", icon: ChartPie },
  { to: "/sugestoes", label: "Sugestões", icon: Lightbulb },
] as const;

function AuthenticatedLayout() {
  const navigate = useNavigate();
  const [quickAddOpen, setQuickAddOpen] = useState(false);

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      <div className="mx-auto max-w-7xl px-4 pb-28 pt-5 sm:px-6 lg:px-10">
        <header className="flex items-center justify-between gap-3">
          <Link to="/" className="flex items-center gap-2">
            <span className="inline-grid size-9 place-items-center rounded-full bg-ink font-display text-base text-paper">
              ₿
            </span>
            <span className="font-display text-xl font-semibold tracking-tight">Cofre</span>
          </Link>

          <nav className="hidden items-center gap-7 text-[15px] text-ink/70 md:flex">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: item.to === "/" }}
                activeProps={{ className: "text-ink font-medium" }}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setQuickAddOpen(true)}
              className="hidden rounded-full bg-ink px-4 py-2 text-sm font-medium text-paper transition-opacity hover:opacity-90 sm:block"
            >
              + Lançar gasto
            </button>
            <button
              onClick={signOut}
              title="Sair"
              className="grid size-9 place-items-center rounded-full border border-line bg-card text-muted-foreground transition-colors hover:text-foreground"
            >
              <LogOut className="size-4" />
            </button>
          </div>
        </header>

        <Outlet />
      </div>

      {/* Bottom nav (mobile) */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-card/95 backdrop-blur md:hidden">
        <div className="mx-auto flex max-w-md items-center justify-between px-6 py-2">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.to === "/" }}
              className="flex flex-col items-center gap-0.5 py-1 text-ink/50"
              activeProps={{ className: "flex flex-col items-center gap-0.5 py-1 text-ink" }}
            >
              <item.icon className="size-5" />
              <span className="text-[10px]">{item.label}</span>
            </Link>
          ))}
        </div>
      </nav>

      {/* Floating quick-add (mobile) */}
      <button
        onClick={() => setQuickAddOpen(true)}
        className="fixed bottom-20 right-5 z-40 flex items-center gap-2 rounded-full bg-terracotta px-5 py-3 text-sm font-semibold text-paper shadow-lg transition-transform hover:scale-105 md:hidden"
      >
        <Plus className="size-4" /> Lançar gasto
      </button>

      <QuickAddDialog open={quickAddOpen} onOpenChange={setQuickAddOpen} />
    </div>
  );
}
