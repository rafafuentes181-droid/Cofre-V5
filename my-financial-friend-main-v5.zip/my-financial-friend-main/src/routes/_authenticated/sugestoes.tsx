import { createFileRoute } from "@tanstack/react-router";
import { Lightbulb } from "lucide-react";
import { buildSuggestions } from "@/lib/finance";
import { useTransactions } from "./index";

export const Route = createFileRoute("/_authenticated/sugestoes")({
  head: () => ({
    meta: [
      { title: "Sugestões — Cofre" },
      { name: "description", content: "Sugestões de economia baseadas nos seus gastos reais." },
      { property: "og:title", content: "Sugestões — Cofre" },
      { property: "og:description", content: "Sugestões de economia baseadas nos seus gastos reais." },
    ],
  }),
  component: SugestoesPage,
});

function SugestoesPage() {
  const { data: transactions = [] } = useTransactions();
  const tips = buildSuggestions(transactions);

  return (
    <div className="mt-8 space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight">Sugestões de economia</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Geradas automaticamente a partir dos seus lançamentos deste mês.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {tips.map((tip, i) => (
          <section
            key={i}
            className={`rounded-3xl p-6 ${i === 0 ? "bg-sage text-paper" : "border border-line bg-card"}`}
          >
            <Lightbulb className={`size-5 ${i === 0 ? "text-paper/70" : "text-gold"}`} />
            <p
              className={`mt-3 font-display text-lg font-medium leading-snug ${
                i === 0 ? "text-paper" : "text-ink"
              }`}
            >
              {tip}
            </p>
          </section>
        ))}
      </div>

      <p className="text-center text-[13px] text-muted-foreground">
        Quanto mais fiel você for nos lançamentos, melhores ficam as sugestões.
      </p>
    </div>
  );
}
