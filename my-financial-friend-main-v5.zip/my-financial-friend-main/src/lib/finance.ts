export const CATEGORIES = [
  "Moradia",
  "Mercado",
  "Restaurantes",
  "Transporte",
  "Lazer",
  "Assinaturas",
  "Saúde",
  "Educação",
  "Renda",
  "Outros",
] as const;

export const CATEGORY_COLORS: Record<string, string> = {
  Moradia: "bg-sage",
  Mercado: "bg-sage",
  Restaurantes: "bg-terracotta",
  Transporte: "bg-gold",
  Lazer: "bg-ink/60",
  Assinaturas: "bg-terracotta/70",
  Saúde: "bg-sage/70",
  Educação: "bg-gold/70",
  Renda: "bg-sage",
  Outros: "bg-ink/40",
};

export function formatBRL(value: number): string {
  return value.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

export function formatDateBR(iso: string): string {
  const parts = iso.split("-").map(Number);
  const date = new Date(parts[0] ?? 0, (parts[1] ?? 1) - 1, parts[2] ?? 1);
  return date.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "short",
  });
}

export function monthKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

export type Transaction = {
  id: string;
  description: string;
  amount: number;
  type: "entrada" | "saida";
  category: string;
  source: "conta" | "cartao";
  account_id: string | null;
  card_id: string | null;
  occurred_at: string;
  is_forecast: boolean;
  recurrence_group: string | null;
};

export type CreditCard = {
  id: string;
  name: string;
  credit_limit: number;
  closing_day: number;
  due_day: number;
};

export type Account = {
  id: string;
  name: string;
};

/** Rule-based savings suggestions derived from the user's transactions. */
export function buildSuggestions(transactions: Transaction[]): string[] {
  const tips: string[] = [];
  const now = new Date();
  const thisMonth = transactions.filter(
    (t) => t.type === "saida" && t.occurred_at.startsWith(monthKey(now)),
  );
  const byCategory = new Map<string, number>();
  for (const t of thisMonth) {
    byCategory.set(t.category, (byCategory.get(t.category) ?? 0) + t.amount);
  }

  const restaurantes = byCategory.get("Restaurantes") ?? 0;
  if (restaurantes > 300) {
    const saving = Math.round(restaurantes * 0.25);
    tips.push(
      `Você já gastou ${formatBRL(restaurantes)} em restaurantes este mês. Trocar 2 pedidos por marmita economiza cerca de ${formatBRL(saving)}/mês.`,
    );
  }

  const assinaturas = byCategory.get("Assinaturas") ?? 0;
  if (assinaturas > 0) {
    tips.push(
      `Assinaturas somam ${formatBRL(assinaturas)}/mês (${formatBRL(assinaturas * 12)}/ano). Revise as que você não usa — cancelar uma já faz diferença.`,
    );
  }

  const transporte = byCategory.get("Transporte") ?? 0;
  if (transporte > 400) {
    tips.push(
      `Transporte está em ${formatBRL(transporte)} este mês. Avalie passe mensal ou carona para reduzir até 20%.`,
    );
  }

  const entradas = transactions
    .filter((t) => t.type === "entrada" && t.occurred_at.startsWith(monthKey(now)))
    .reduce((s, t) => s + t.amount, 0);
  const saidas = thisMonth.reduce((s, t) => s + t.amount, 0);
  if (entradas > 0 && saidas / entradas > 0.8) {
    tips.push(
      `Você está gastando ${Math.round((saidas / entradas) * 100)}% do que entra. Tente a regra 50/30/20: 50% necessidades, 30% desejos, 20% poupança.`,
    );
  } else if (entradas > 0) {
    tips.push(
      `Bom ritmo! Você gastou ${Math.round((saidas / entradas) * 100)}% da renda este mês. Considere guardar a diferença assim que o salário cair.`,
    );
  }

  if (tips.length === 0) {
    tips.push(
      "Lance seus gastos com frequência para receber sugestões de economia personalizadas aqui.",
    );
  }
  return tips.slice(0, 4);
}
