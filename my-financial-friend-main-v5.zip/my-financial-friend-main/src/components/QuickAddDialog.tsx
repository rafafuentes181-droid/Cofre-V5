import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORIES, type Account, type CreditCard } from "@/lib/finance";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type Props = { open: boolean; onOpenChange: (open: boolean) => void };

export function QuickAddDialog({ open, onOpenChange }: Props) {
  const queryClient = useQueryClient();
  const [type, setType] = useState<"saida" | "entrada">("saida");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState<string>("Outros");
  const [source, setSource] = useState<"conta" | "cartao">("conta");
  const [accountId, setAccountId] = useState<string>("");
  const [cardId, setCardId] = useState<string>("");
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [forecast, setForecast] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [repeatCount, setRepeatCount] = useState("1");

  const { data: accounts = [] } = useQuery({
    queryKey: ["accounts"],
    queryFn: async () => {
      const { data, error } = await supabase.from("accounts").select("*").order("name");
      if (error) throw error;
      return data as Account[];
    },
  });

  const { data: cards = [] } = useQuery({
    queryKey: ["credit_cards"],
    queryFn: async () => {
      const { data, error } = await supabase.from("credit_cards").select("*").order("name");
      if (error) throw error;
      return data as CreditCard[];
    },
  });

  const mutation = useMutation({
    mutationFn: async () => {
      const parsed = Number(amount.replace(",", "."));
      if (!description.trim() || !parsed || parsed <= 0) {
        throw new Error("Preencha descrição e um valor válido.");
      }
      const { data: userData } = await supabase.auth.getUser();
      const userId = userData.user?.id;
      if (!userId) throw new Error("Sessão expirada. Entre novamente.");
      const times = repeat ? Math.max(1, Math.min(120, Number(repeatCount) || 1)) : 0;
      const group = repeat ? crypto.randomUUID() : null;
      const base = {
        user_id: userId,
        description: description.trim(),
        amount: parsed,
        type,
        category,
        source,
        account_id: source === "conta" ? accountId || null : null,
        card_id: source === "cartao" ? cardId || null : null,
        recurrence_group: group,
      };
      const [y, m, d] = date.split("-").map(Number);
      const rows = [{ ...base, occurred_at: date, is_forecast: forecast || repeat }];
      for (let i = 1; i <= times; i++) {
        const dt = new Date(y!, m! - 1, d! + 30 * i);
        const iso = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
        rows.push({ ...base, occurred_at: iso, is_forecast: true });
      }
      const { error } = await supabase.from("transactions").insert(rows);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(type === "saida" ? "Gasto lançado!" : "Entrada lançada!");
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      setDescription("");
      setAmount("");
      setRepeat(false);
      setForecast(false);
      setRepeatCount("1");
      onOpenChange(false);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : "Erro ao lançar"),
  });

  const inputCls =
    "w-full rounded-xl border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-3xl border-line bg-card sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {type === "saida" ? "Lançar gasto" : "Lançar entrada"}
          </DialogTitle>
        </DialogHeader>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            mutation.mutate();
          }}
          className="space-y-3"
        >
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setType("saida")}
              className={`rounded-full py-2 text-sm font-medium transition-colors ${
                type === "saida" ? "bg-terracotta text-paper" : "bg-secondary text-secondary-foreground"
              }`}
            >
              Saída
            </button>
            <button
              type="button"
              onClick={() => setType("entrada")}
              className={`rounded-full py-2 text-sm font-medium transition-colors ${
                type === "entrada" ? "bg-sage text-paper" : "bg-secondary text-secondary-foreground"
              }`}
            >
              Entrada
            </button>
          </div>

          <input
            autoFocus
            required
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Descrição (ex.: Mercado, Uber, Salário)"
            className={inputCls}
          />

          <div className="grid grid-cols-2 gap-2">
            <input
              required
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Valor (R$)"
              className={inputCls}
            />
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className={inputCls}
            />
          </div>

          <select value={category} onChange={(e) => setCategory(e.target.value)} className={inputCls}>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setSource("conta")}
              className={`rounded-full py-2 text-sm font-medium transition-colors ${
                source === "conta" ? "bg-ink text-paper" : "bg-secondary text-secondary-foreground"
              }`}
            >
              Conta corrente
            </button>
            <button
              type="button"
              onClick={() => setSource("cartao")}
              className={`rounded-full py-2 text-sm font-medium transition-colors ${
                source === "cartao" ? "bg-ink text-paper" : "bg-secondary text-secondary-foreground"
              }`}
            >
              Cartão de crédito
            </button>
          </div>

          {source === "conta" && accounts.length > 0 && (
            <select value={accountId} onChange={(e) => setAccountId(e.target.value)} className={inputCls}>
              <option value="">Qual conta?</option>
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
          )}
          {source === "cartao" && cards.length > 0 && (
            <select value={cardId} onChange={(e) => setCardId(e.target.value)} className={inputCls}>
              <option value="">Qual cartão?</option>
              {cards.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          )}

          <div className="space-y-2 rounded-2xl bg-secondary/60 p-3 text-sm">
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={forecast || repeat} disabled={repeat} onChange={(e) => setForecast(e.target.checked)} />
              Previsão (ainda não aconteceu — entra só no saldo projetado)
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={repeat} onChange={(e) => setRepeat(e.target.checked)} />
              Repetir a cada 30 dias
            </label>
            {repeat && (
              <label className="flex items-center gap-2 pl-6">
                Repetir
                <input
                  type="number"
                  min={1}
                  max={120}
                  value={repeatCount}
                  onChange={(e) => setRepeatCount(e.target.value)}
                  className="w-16 rounded-lg border border-input bg-background px-2 py-1"
                />
                vezes
              </label>
            )}
          </div>

          <button
            type="submit"
            disabled={mutation.isPending}
            className="w-full rounded-full bg-ink py-2.5 text-sm font-medium text-paper transition-opacity hover:opacity-90 disabled:opacity-50"
          >
            {mutation.isPending ? "Salvando…" : "Salvar lançamento"}
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
